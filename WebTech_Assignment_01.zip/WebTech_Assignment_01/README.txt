COMSATS University Islamabad - Sahiwal Campus
Web Technologies (CSC-336) - Assignment 1, Fall 2026

How to run: open the main HTML file of each task folder in any browser (double-click).
No server or installation is required.

Task1/  index.html                      - tags and formatting practice (COMSATS page)
Task2/  library.html                    - library page: lists, text formatting, images, video
Task3/  library.html                    - same page with inline styling
Task4/  library.html, departments.html, admissions.html  - in-page links + tables
Task5/  index.html                      - table-based layout (header, nav, 3 columns, footer)
Task6/  job_application.html            - CUI non-faculty job application form
Task7/  signup.html, terms.html         - sign-up template (tables + forms + colours)
Task8/  index.html, css/style.css       - login + sign-up template (tables + external CSS)
Task9/  index.html, css/style.css       - contact template (tables + external CSS)
Task10/ index.html, css/style.css       - personal portfolio landing page

Notes:
- images/ and video/ in Tasks 2-4 contain sample library images and a short sample video.
  Replace them (same file names) with real photos/video of the COMSATS library if you have them.
- Task 10 contact details (email, GitHub, LinkedIn) are placeholders: edit them in index.html.
